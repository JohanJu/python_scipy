package gui;

import java.awt.Color;
import javax.swing.JTextField;

public class Editor extends JTextField {
    public Editor() {
        setBackground(Color.WHITE);
    }
}